const API_URL = 'http://10.106.34.166:3004/api'; 

export default API_URL;
